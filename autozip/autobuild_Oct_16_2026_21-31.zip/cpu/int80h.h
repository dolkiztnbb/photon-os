#ifndef SYSCALLS_H
#define SYSCALLS_H

#include <drivers/screen.h>
#include <drivers/keyboard.h>
#include <libc/string.h>
#include <cpu/isr.h>
#include <cpu/idt.h>

void int80h(registers_t *r);

// VFS / Файловая система
#define SYS_OPEN         0x01 // Открытие / создание файла
#define SYS_READ         0x02 // Чтение из дескриптора
#define SYS_WRITE        0x03 // Запись в дескриптор
#define SYS_CLOSE        0x04 // Закрытие дескриптора
#define SYS_SEEK         0x05 // Смещение файлового указателя
#define SYS_QUERY        0x06 // Запрос информации о файле по FD
// UNIMPLEMENTED
#define SYS_SET_IO_COLOR 0x07 // Настройка цветов ввода/вывода (legacy)
#define SYS_READDIR      0x08 // Чтение записи из директории
#define SYS_MKDIR        0x09 // Создание новой директории
#define SYS_UNLINK       0x0A // Удаление файла или пустой папки (rm)
#define SYS_STAT         0x0B // Получение информации о файле по пути
#define SYS_CHDIR        0x0C // Смена текущей рабочей директории процесса
#define SYS_GETCWD       0x0D // Получение пути текущей рабочей директории (pwd)
#define SYS_DUP2         0x0E // Дублирование/перенаправление файлового дескриптора

// ----------------------------------------------------------------------------
// 2. Управление памятью (0x10 - 0x1F)
// ----------------------------------------------------------------------------
#define SYS_MALLOC       0x10 // Выделение динамической памяти ядра/процесса
#define SYS_FREE         0x11 // Освобождение выделенной памяти
// UNIMPLEMENTED
#define SYS_MSTATUS      0x12 // Получение информации о занятой памяти
#define SYS_BRK          0x13 // Управление верхней границей кучи (sbrk для libc)
#define SYS_MMAP         0x14 // Отображение страниц памяти в процесс
#define SYS_MUNMAP       0x15 // Снятие отображения страниц
#define SYS_SHM_CREATE   0x16 // Создание разделяемого фреймбуфера
#define SYS_SHM_ATTACH   0x17 // Подключение фреймбуфера в процесс
#define SYS_SHM_DETACH   0x18 // Отключение фреймбуфера

// ----------------------------------------------------------------------------
// 3. Процессы и многозадачность (0x20 - 0x2F)
// ----------------------------------------------------------------------------
#define SYS_ADD_TASK     0x20 // Создание потока ядра
#define SYS_KILL_TASK    0x21 // Принудительное уничтожение задачи по PID
// UNIMPLEMENTED
#define SYS_EXEC         0x22 // Запуск PEX исполняемого файла
#define SYS_EXIT         0x23 // Завершение текущего процесса
#define SYS_WAITPID      0x24 // Ожидание завершения дочернего процесса (exit status)
#define SYS_GETPID       0x25 // Получить PID текущего процесса
#define SYS_YIELD        0x26 // Добровольная уступка кванта времени CPU
#define SYS_SLEEP        0x27 // Сон процесса на N миллисекунд / тиков
#define SYS_GETUID       0x28 // Получить UID текущего процесса (0 = root)
#define SYS_REBOOT       0x29 // Аппаратная перезагрузка системы
#define SYS_SETUID       0x2A // Установить UID процесса

// ----------------------------------------------------------------------------
// 4. Консоль, TTY и экран (0x30 - 0x3F)
// ----------------------------------------------------------------------------
#define SYS_SETIOCOL     0x30 // Установка цветов текста и фона консоли
#define SYS_SETIOFL      0x31 // Установка флагов режима ввода (echo, raw и т.д.)
#define SYS_GOTOXY       0x32 // Перемещение курсора в координаты (x, y)
// UNIMPLEMENTED
#define SYS_GET_CURSOR   0x33 // Получение текущих координат курсора
#define SYS_POLL_KEY     0x34 // Неблокирующая проверка наличия символа в буфере
#define SYS_CLEAR_SCR    0x35 // Очистка экрана (cls / clear)
#define SYS_GET_SCR_SIZE 0x36 // Получение размера экрана (столбцы, строки)
#define SYS_GET_MOUSE_DELTA 0x37 // Получение дельты перемещения и кнопок мыши

typedef struct {
    int32_t dx;
    int32_t dy;
    uint8_t buttons; // бит 0: Left, бит 1: Right, бит 2: Middle
} mouse_state_t;

// ----------------------------------------------------------------------------
// 5. Системное время и таймеры (0x40 - 0x4F)
// ----------------------------------------------------------------------------
// UNIMPLEMENTED
#define SYS_GET_TICKS    0x40 // Uptime: системные тики с момента старта
#define SYS_GET_TIME     0x41 // Чтение реального времени из RTC (ч, м, с)
#define SYS_GET_DATE     0x42 // Чтение даты из RTC (д, м, г)

// ----------------------------------------------------------------------------
// 6. Межпроцессное взаимодействие и сигналы (0x50 - 0x5F)
// ----------------------------------------------------------------------------
// UNIMPLEMENTED
#define SYS_PIPE         0x50 // Создание безымянного канала ввода-вывода
#define SYS_SIGNAL       0x51 // Отправка сигнала процессу (kill, SIGINT, SIGTERM)

// ----------------------------------------------------------------------------
// 7. Привилегированный доступ: AHCI / Диск (0x80 - 0x8F)
// ----------------------------------------------------------------------------
// WILL BE DEPRECATED
#define SYS_AHCI_READ    0x80 // Прямое чтение секторов LBA
#define SYS_AHCI_WRITE   0x81 // Прямая запись секторов LBA
#define SYS_DEV_COUNT    0x82
#define SYS_DEV_INFO     0x83
#define SYS_DEV_READ     0x84
#define SYS_DEV_WRITE    0x85

typedef struct {
    char     name[8];
    char     model[41];
    uint32_t total_sectors;
    uint32_t sector_size;
    uint32_t flags;
    uint8_t  is_boot;
} disk_info_t;
// ----------------------------------------------------------------------------
// 8. Привилегированный доступ: PCI (0x90 - 0x9F)
// ----------------------------------------------------------------------------
// WILL BE DEPRECATED
#define SYS_PCI_READ     0x90 // Чтение 32-битного регистра конфигурации PCI
#define SYS_PCI_WRITE    0x91 // Запись 32-битного регистра конфигурации PCI
#define SYS_PCI_SCAN     0x92 // Сканирование шины PCI

#endif